package com.kursovaya.eventsGeoPositioning.repository;

import com.kursovaya.eventsGeoPositioning.model.Event;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface EventRepository extends MongoRepository<Event, String> {

    Event findById(Long id);
}
