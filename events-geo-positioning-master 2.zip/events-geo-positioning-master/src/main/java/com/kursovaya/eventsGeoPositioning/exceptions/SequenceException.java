package com.kursovaya.eventsGeoPositioning.exceptions;

public class SequenceException extends RuntimeException {
    public SequenceException(String message) {
        super(message);
    }
}
