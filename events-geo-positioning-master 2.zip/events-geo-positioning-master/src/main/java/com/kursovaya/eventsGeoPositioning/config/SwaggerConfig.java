package com.kursovaya.eventsGeoPositioning.config;

import com.fasterxml.classmate.TypeResolver;
import com.kursovaya.eventsGeoPositioning.model.Event;
import com.kursovaya.eventsGeoPositioning.model.Role;
import com.kursovaya.eventsGeoPositioning.model.Sequence;
import com.kursovaya.eventsGeoPositioning.model.User;
import com.kursovaya.eventsGeoPositioning.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfig {
    @Autowired
    private TypeResolver typeResolver;

    @Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.kursovaya.eventsGeoPositioning"))
                .paths(PathSelectors.any())
                .build()
                .additionalModels(typeResolver.resolve(User.class),typeResolver.resolve(Event.class),
                        typeResolver.resolve(Sequence.class),typeResolver.resolve(Role.class))
                .apiInfo(apiInfo());
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder().title("Events Geo Positioning")
                .description("REST API")
                .contact(new Contact("kursovaya", "https://vk.com/zxcqwemode", "stepa.naumecc@gmail.com"))
                .version("1.1.2")
                .build();
    }
}
